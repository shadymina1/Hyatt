﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace final_hotel.Models
{
    public class Contact
    {


        public String firstName { get; set; }

        public String lastName { get; set; }

        public String email { get; set; }

        public String subject { get; set; }

        public String message { get; set; }
    }
}
