﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Threading.Tasks;

namespace final_hotel.Models
{
    public class Booking
    {
       
        public DateTime chkin { get; set; }

        public DateTime chkout { get; set; }

    }
}
